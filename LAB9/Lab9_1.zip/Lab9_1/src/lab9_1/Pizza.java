package lab9_1;

/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
class Pizza {
    private String name;
    private double price;

    public Pizza(String name, double price) {
        this.name = name;
        this.price = price;
    }

    @Override
    public String toString(){
        return name + " price : " + price;
    }


    public double getPrice() {
        return price;
    }   
}
