package lab12_3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author 6234424023 ธนดล สิทธานนท์ 
 * MR.THANADOL SITTANON ID:6234424023
 */
public class FileMatch {

    public static void main(String[] args) {
        ArrayList<AccountRecord> acctRec = new ArrayList<>();
        ArrayList<TransactionRecord> transRec = new ArrayList<>();        
        
        try {
            File master = new File("master.txt");
            File trans = new File("trans.txt");
            Scanner scanAcct = new Scanner(master);
            Scanner scanTrans = new Scanner(trans);
            
            while (scanAcct.hasNextLine()) 
            {   
            String dataline = scanAcct.nextLine().trim();
            String[] data = dataline.split(" ");
            acctRec.add(new AccountRecord(Integer.parseInt(data[0]),data[1]+" "+data[2],Double.parseDouble(data[3])));
            }
            
            while (scanTrans.hasNextLine()) 
            {   
            String dataline = scanTrans.nextLine().trim();
            String[] data = dataline.split(" ");
            transRec.add(new TransactionRecord(Integer.parseInt(data[0]),Double.parseDouble(data[1])));
            }            
            
            for (AccountRecord a : acctRec){
                for (TransactionRecord t : transRec){
                    a.combine(t);
                }
            }
            
        } catch (FileNotFoundException ex) {
            System.out.println(ex);
        }
        
        try(RandomAccessFile r = new RandomAccessFile("newMaster.dat", "rw")) {
            
            for (AccountRecord a : acctRec) {
                r.writeInt(a.getAcctNo());
                r.writeChar('\n');
                String name = (a.getName().length()>30)? a.getName().substring(0, 30) : a.getName();
                for (int i = name.length(); i < 30; i++) {
                    name += " ";
                }
                r.writeChars(name);
                r.writeChar('\n');
                r.writeDouble(a.getBalance());
                r.writeChar('\n');
                r.writeInt(a.getTransCnt());
                r.writeChar('\n');
            }
            
        } catch (FileNotFoundException ex) {
            System.out.println(ex);
        } catch (IOException ex) {
            System.out.println(ex);
        }
        
        ArrayList<AccountRecord> acctRecRead = new ArrayList<>();
        try (RandomAccessFile r = new RandomAccessFile("newMaster.dat", "r")) {
            while (r.getFilePointer() < r.length()) {
                
                int accNo = r.readInt();
                r.seek(r.getFilePointer()+2);
                
                String name = r.readLine();
                Double balance = r.readDouble();
                
                r.seek(r.getFilePointer()+2);
                int transCnt = r.readInt();
                r.seek(r.getFilePointer()+2);
                
                AccountRecord a = new AccountRecord(accNo, name, balance, transCnt);
                acctRecRead.add(a);
            }
            
        double balance = 0;
        int noTrans = 0;
        
        for (AccountRecord a : acctRecRead) {
            balance += a.getBalance();
            if (a.getTransCnt() == 0) noTrans++;
        }
        
        System.out.print("Total Account Record : ");
        System.out.println(acctRecRead.size());
        System.out.print("Total Balance : ");
        System.out.println(balance);
        System.out.print("No transaction : ");
        System.out.println(noTrans + " account.");
        
        }
        catch (FileNotFoundException ex) {
            System.out.println(ex);
        }
        catch (IOException ex) {
            System.out.println(ex);
        }

    }
    
}
