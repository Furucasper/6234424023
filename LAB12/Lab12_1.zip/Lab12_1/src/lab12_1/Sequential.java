package lab12_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * @author 6234424023 ธนดล สิทธานนท์ 
 * MR.THANADOL SITTANON ID:6234424023
 */
public class Sequential {

    public static void main(String[] args) throws FileNotFoundException {
        
        String text;
        int cntChar = 0;
        int cntWord = 0;
        int cntLine = 0; 
        Scanner in = new Scanner(System.in);
        File file = new File("output.txt");
        PrintWriter out = new PrintWriter(file);
        
        do{
            text = (in.nextLine());
            if(!text.equals("quit")){
                out.print(text+"\n");
            }
        }while(!text.equals("quit"));
        
        out.close();
        Scanner scan = new Scanner(file);
        
        while (scan.hasNextLine()) 
        {   
            cntLine++;
            String line = scan.nextLine();
            cntChar += line.length();
            String[] words = line.trim().split(" ");
            cntWord += words.length;
        }
        
        scan.close();
        
        System.out.println("Total characters : " + cntChar);
        System.out.println("Total words : " + cntWord);
        System.out.println("Total lines : " + cntLine);
    }
}
