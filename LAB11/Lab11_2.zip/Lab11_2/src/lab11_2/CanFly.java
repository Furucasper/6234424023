package lab11_2;

/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
public interface CanFly {
    void fly(Terrain terrain);
}
