package lab3_1;
/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
public class InsectPopulationTester {
    public static void main(String[] args) {
        InsectPopulation inpop = new InsectPopulation(10);
        for(int i=0;i<=2;i++){
            inpop.breed();
            inpop.spray();
            System.out.println("Number of insects : "+inpop.getPop());
        }
  }
}
