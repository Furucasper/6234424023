package lab3_1;
/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
public class InsectPopulation {
      private double inspop;
      public InsectPopulation(double n){inspop = n;}
      public void spray(){ inspop = inspop*0.9;}
      public void breed(){ inspop = inspop*2;}
      public double getPop(){ return inspop;}
}

