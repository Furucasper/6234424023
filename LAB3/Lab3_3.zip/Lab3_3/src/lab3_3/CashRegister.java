package lab3_3;
/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
public class CashRegister {
    private double sumVat,sumPrice,changeCash;
    private final double vat;
    
    public CashRegister(double tax){
        vat = (tax/100);
    }
    
    public void recordTexablePurchase(double amount){
        sumVat += (amount*vat);
        sumPrice+=(amount*(1+vat));
    }
    
    public void recordPurchase(double amount) {
        sumPrice+=amount;
    }
    
    public void enterPayment(double cash){
        changeCash = cash-sumPrice;
    }
    
    public double getTotalTax(){ return sumVat; }
    
    public double giveChange(){
    	sumPrice = 0;
    	sumVat = 0;
    	return changeCash;
    	}
}
