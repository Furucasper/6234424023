package lab12_3;

/**
 * @author 6234424023 ธนดล สิทธานนท์ 
 * MR.THANADOL SITTANON ID:6234424023
 */
public class AccountRecord {
    
    private int acctNo;
    private String name;
    private double balance;
    private int transCnt = 0; // นับว่า บัญชีนี้ทารายการ transaction ไปกี่ครั้ง
    
    public AccountRecord (int acctNo, String name, double balance) {
        this.acctNo = acctNo;
        this.name = name;
        this.balance = balance;
    }
    
    public AccountRecord (int acctNo, String name, double balance, int transCnt) {
        this.acctNo = acctNo;
        this.name = name;
        this.balance = balance;
        this.transCnt = transCnt;
    }
    
    public void combine(TransactionRecord t){
        if (t.getAcctNo() != this.acctNo) 
        {
            return;
        }
        this.balance += t.getBalance();
        this.transCnt += t.getTransCnt();
    }
    
    public int getAcctNo() { return acctNo; }
    public String getName() { return name; }
    public double getBalance(){ return balance; }
    public int getTransCnt() { return transCnt; }
}
