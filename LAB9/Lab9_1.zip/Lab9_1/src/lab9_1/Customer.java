package lab9_1;

/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
class Customer {
    private String name,tel;

    public Customer(String name, String tel) {
        this.name = name;
        this.tel = tel;
    }

    @Override
    public String toString(){
        return name + " tel : " + tel;
    }

}
    
