/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_2;

/**
 *
 * @author Thanadol Sittanon ID:6234424023
 */
public class HollePrintor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String str = new String("Hello, World!");
        str.replace("o", "O");
        str.replace("e", "o");
        str.replace("o", "e");
        System.out.println(str.replace("O","o"));
    }
    
}
