package lab11_1;

import java.util.ArrayList;

/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
class MusicBox implements SimpleQueue{
    
    private ArrayList muBox;

    public MusicBox() {
        muBox = new ArrayList<>();
    }

    @Override
    public void dequeue() {
        System.out.println("Now playing "+muBox.get(0));
        muBox.remove(0);
    }

    @Override
    public void enqueue(Object o) {
        muBox.add(o);
        System.out.println(o+" is added in queue");
    }
    
}
