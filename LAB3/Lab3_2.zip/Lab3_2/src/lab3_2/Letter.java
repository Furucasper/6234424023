package lab3_2;
/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
public class Letter {

    private final String sender;
    private final String receiver;
    private String text = "";
    public Letter(String to,String from){
        sender = from;
        receiver = to;
}
    public void addLine(String line){
        text += line+"\n";
    }
    public String getText(){

        return "Dear "+receiver+":"+"\n\n"+text+"\nSincerely,\n\n"+sender;
    }
    
}
