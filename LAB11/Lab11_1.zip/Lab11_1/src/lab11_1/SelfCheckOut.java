package lab11_1;

import java.util.ArrayList;

/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
class SelfCheckOut implements SimpleQueue {
    
    private ArrayList selfMac;
    private double amount;
    
    public SelfCheckOut(){
        selfMac = new ArrayList<>();
    }

    @Override
    public void dequeue() {
        Object o = selfMac.get(0);
        if (o instanceof Product ) {
            amount += ((Product) o).getPrice();
        }
        selfMac.remove(0);
    }

    public double getAmount() {
        return amount;
    }

    @Override
    public void enqueue(Object o) {
        selfMac.add(o);
        if (o instanceof Product ) {
           System.out.println(((Product) o).getName() + " is added in queue");
        }  
    }
}
