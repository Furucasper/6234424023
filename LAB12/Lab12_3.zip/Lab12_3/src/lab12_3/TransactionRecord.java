package lab12_3;

/**
 * @author 6234424023 ธนดล สิทธานนท์ 
 * MR.THANADOL SITTANON ID:6234424023
 */
public class TransactionRecord {
    
    private int acctNo;
    private int transCnt;
    private double balance;

    public TransactionRecord(int acctNo, double balance) {
        this.acctNo = acctNo;
        this.balance = balance;
        transCnt = 1;
    }

    public int getAcctNo() {
        return acctNo;
    }

    public double getBalance() {
        return balance;
    }

    public int getTransCnt() {
        return transCnt;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public void setTransCnt(int transCnt) {
        this.transCnt = transCnt;
    }

    
    
}
