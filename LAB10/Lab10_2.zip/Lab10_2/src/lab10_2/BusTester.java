package lab10_2;

import java.util.ArrayList;

/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
public class BusTester {
    
    public static void main(String[] args) {
        
        ArrayList arr = new ArrayList<>();
        
        arr.add(new Hybrid(45, 1.2, 600, 150, 1));
        arr.add(new CNGBus(50, 1, 200, 2)); 
        
        for(Object b : arr){
            
            if (b instanceof Hybrid){
                System.out.println("ID: "+((Hybrid) b).getID());
                System.out.println("Emission Tier: "+((Hybrid) b).getEmissionTier());
                System.out.println("Accel: "+((Hybrid) b).getAccel());
            }
            
            if(b instanceof CNGBus){
                System.out.println("ID: "+((CNGBus) b).getID());
                System.out.println("Emission Tier: "+((CNGBus) b).getEmissionTier());
                System.out.println("Accel: "+((CNGBus) b).getAccel());
                
            }
        }
    }
    
}
