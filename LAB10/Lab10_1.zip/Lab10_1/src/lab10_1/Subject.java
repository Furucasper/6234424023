package lab10_1;

/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
public class Subject implements Evaluation{
    private String subjName;
    private int score[];

    public Subject(String subjName, int score[]) {
        this.subjName = subjName;
        this.score = score;
    }
    @Override
    public double evaluate(){
        double totalScore = 0;
        for(int sc : score){
            totalScore+=sc;
        }
        return totalScore;
    }
    
    @Override
    public char grade(double sc){
        if(sc>=0)
            return 'P';
        else 
            return 'F'; 
    }
    
    @Override
    public String toString(){
        return subjName;
    }
}
