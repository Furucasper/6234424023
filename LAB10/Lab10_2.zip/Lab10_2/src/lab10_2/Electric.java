package lab10_2;

/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
public interface Electric {
    double LOW_VOLTAGE = 480;
    double HIGH_VOLTAGE = 600;
    double getVoltage();
}
