package lab10_1;

/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
public interface Evaluation {
    double evaluate();
    char grade(double sc);
}
