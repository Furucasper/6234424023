/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_3;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author Thanadol Sittanon ID:6234424023
 */
public class Gregorian {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GregorianCalendar cal = new GregorianCalendar();
        GregorianCalendar myBirthday = new GregorianCalendar(2001,Calendar.APRIL,11);
        cal.add(Calendar.DAY_OF_MONTH, 100);
        myBirthday.add(Calendar.DAY_OF_MONTH, 10000);
        System.out.println(cal);
        
        int dayCal = cal.get(Calendar.DAY_OF_MONTH);
        int monthCal = cal.get(Calendar.MONTH);
        int yearCal = cal.get(Calendar.YEAR);
        int weekendCal = cal.get(Calendar.DAY_OF_WEEK);
        int dayMB = myBirthday.get(Calendar.DAY_OF_MONTH);
        int monthMB = myBirthday.get(Calendar.MONTH);
        int yearMB = myBirthday.get(Calendar.YEAR);
        int weekendMB = myBirthday.get(Calendar.DAY_OF_WEEK);
        //String
  
        //System.out.println(cal.get(Calendar.DAY_OF_MONTH));
        System.out.println(weekendCal +" "+ dayCal+" " + monthCal+" "+ yearCal);
        System.out.println(weekendMB +" "+ dayMB+" " + monthMB+" "+ yearMB);
        
    
        
    }
    
}
