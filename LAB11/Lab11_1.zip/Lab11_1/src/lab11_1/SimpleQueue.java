package lab11_1;

/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
public interface SimpleQueue {
    void enqueue(Object o);
    void dequeue();
}
