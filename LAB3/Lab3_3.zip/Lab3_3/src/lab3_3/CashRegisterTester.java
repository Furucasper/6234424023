package lab3_3;
/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
public class CashRegisterTester {
    public static void main(String[] args){
        CashRegister creg = new CashRegister(7);
        creg.recordPurchase(50);
        creg.recordPurchase(10);
        creg.recordTexablePurchase(20);
        creg.enterPayment(100);
        System.out.println("Your change is "+String.format("%.1f",creg.giveChange()));
    }
}
