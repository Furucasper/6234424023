package lab10_2;

/**
 * @author MR.THANADOL SITTANON
 */
public interface LiquidFuel {
    double getRange();
    int getEmissionTier();
    
}
