package lab11_1;

/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
public class Product {
    private String name;
    private double price;
    public Product(String n, double p) {
        name = n;
        price = p;
    }
    public String getName() {
        return name;
    }
    public double getPrice() {
        return price;
    }
}
