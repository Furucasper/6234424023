package lab11_2;

/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
public interface CanWalk {
    void walk(Terrain terrain);
    void run(Terrain terrain);
}
