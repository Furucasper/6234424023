package lab10_1;

/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
public class Secretary extends Employee implements Evaluation{
   private int typingSpeed;
   private int[] score;

    public Secretary(String name, int salary, int score[], int typingSpeed) {
        super(name, salary);
        this.typingSpeed = typingSpeed;
        this.score = score;
    }

    @Override
    public double evaluate(){
        double totalScore = 0;
        for(int sc : score){
            totalScore+=sc;
        }
        return totalScore;
    }
    
    @Override
    public char grade(double sc){
        if(sc>=90){
            setSalary(18000);
            return 'P';
        }else{ return 'F'; }
    }
}
