package lab9_1;

import java.util.ArrayList;

/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
class Order {
    public static int cntOrder = 0;
    private int id;
    private Customer c;
    private ArrayList<Pizza>p = new ArrayList<>();

    public Order(Customer c) {
        this.c = c;
        cntOrder++;
        id = cntOrder;
    }

    public void addPizza(Pizza pizza) {
        p.add(pizza);
    }

    public String getOrderDetail() {
        String orderDetail = "Order id : "+id+"\n"+c.toString();
        
        for(Pizza piz : p){
            orderDetail+="\n"+piz.toString();
        }
        
        orderDetail+="\nTotal pieces : "+p.size()+"\n"+"Total cost : "+calculatePayment();
        
        return orderDetail;
    }
 
    public double calculatePayment(){
        double orderPay = 0;
        
        for(Pizza piz : p){
            orderPay+=piz.getPrice();
        }
        
        if(c instanceof GoldCustomer){
            GoldCustomer gc = (GoldCustomer)c;
            orderPay*=(1-(gc.getDiscount()*0.01));
        }
        return orderPay;
    }
    
}
