package lab11_2;

/**
 * @author MR.THANADOL SITTANON ID:6234424023
 */
public abstract class Terrain {
    private String name;
    
    public Terrain(){
        
    }
    
    public Terrain(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public abstract boolean canMove(Animal animal); 
    
}
