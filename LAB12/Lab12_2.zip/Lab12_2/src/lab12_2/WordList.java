package lab12_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author 6234424023 ธนดล สิทธานนท์ 
 * MR.THANADOL SITTANON ID:6234424023
 */
public class WordList {

    public static void main(String[] args) {
        
        try {
            File file = new File("wordlist.txt");
            Scanner scan = new Scanner(file);
            Scanner in = new Scanner(System.in);
            ArrayList<String> wordList = new ArrayList<>();
            
            while (scan.hasNextLine()) 
            {   
            String line = scan.nextLine().trim();
            wordList.add(line);
            }
            
            System.out.print("Enter a sentence: ");
            String sentence = in.nextLine();
            String[]words = sentence.split(" ");
            String contain = "";
            for(String w : words){
                if(!wordList.contains(w))
                    contain += w +" ";
            }
            if(contain.length() == 0) contain = "N/A"; 
            System.out.println("Words not contained: ");
            System.out.println(contain);
            
        } catch (FileNotFoundException ex) {
            System.out.println(ex);
        }
    }
    
}
